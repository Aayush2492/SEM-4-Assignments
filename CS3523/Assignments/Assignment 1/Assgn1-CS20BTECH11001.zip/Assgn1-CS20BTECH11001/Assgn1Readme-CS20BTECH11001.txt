If you are providing the input data in the input.txt file as specified in question, make sure 
the useFileReading variable is true at line 13.
To run the code cd into the directory containing the C file and run the following command:
gcc -w -lm -pthread Assgn1Src-CS20BTECH11001.c -o exec1 && ./exec1

For running simulations for the plot given in report, set the useFileReading variable to false at line 13.
Then run the simulator.py file